package com.kaveri.flowershop2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Flowershop2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
