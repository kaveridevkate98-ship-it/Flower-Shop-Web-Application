package com.kaveri.flowershop2.controller;
import com.paypal.core.PayPalEnvironment;
import com.paypal.core.PayPalHttpClient;
import com.paypal.http.HttpResponse;   // ✅ REQUIRED IMPORT
import com.paypal.orders.*;

import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.*;

@RestController
@RequestMapping("/api/paypal")
@CrossOrigin(origins = "http://localhost:3000")
public class PayPalController {

    //Paste your Sandbox credentials here
    private static final String CLIENT_ID = "ARilL3JTPXQ-2ObQFFwMXyBJ78TgYX_k2B2UeBrhj9Pv1lYDPTkys8z0c7o52ePmYgW0kOdsI1bG2pmD";
    private static final String CLIENT_SECRET = "EIVZ_O9WvyF8xuXfVRVOYWoosf96DJE_TofeHrls7EpJufSbR_6GpiFW4hczVczSXZgHEQo_l9r67PkI";

    // Create PayPal client
    private PayPalHttpClient client() {
        PayPalEnvironment environment =
                new PayPalEnvironment.Sandbox(CLIENT_ID, CLIENT_SECRET);
        return new PayPalHttpClient(environment);
    }

    //CREATE ORDER
    @PostMapping("/create-order")
    public Map<String, String> createOrder(@RequestParam String amount)
            throws IOException {

        OrderRequest orderRequest = new OrderRequest();
        orderRequest.checkoutPaymentIntent("CAPTURE");

        // Set currency & amount
        AmountWithBreakdown amt = new AmountWithBreakdown()
                .currencyCode("USD")   // IMPORTANT: PayPal does not support INR
                .value(amount);

        PurchaseUnitRequest purchaseUnitRequest = new PurchaseUnitRequest()
                .amountWithBreakdown(amt);

        orderRequest.purchaseUnits(List.of(purchaseUnitRequest));

        OrdersCreateRequest request = new OrdersCreateRequest();
        request.requestBody(orderRequest);

        PayPalHttpClient client = client();
        HttpResponse<Order> response = client.execute(request);

        Map<String, String> result = new HashMap<>();
        result.put("id", response.result().id()); // return order ID

        return result;
    }

    // CAPTURE PAYMENT
    @PostMapping("/capture-order")
    public Map<String, Object> captureOrder(@RequestParam String orderId)
            throws IOException {

        OrdersCaptureRequest request = new OrdersCaptureRequest(orderId);
        request.requestBody(new OrderActionRequest());

        PayPalHttpClient client = client();
        HttpResponse<Order> response = client.execute(request);

        Map<String, Object> result = new HashMap<>();
        result.put("status", response.result().status());
        result.put("orderId", orderId);

        return result;
    }
}





