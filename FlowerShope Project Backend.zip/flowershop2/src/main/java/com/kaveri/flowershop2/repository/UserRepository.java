package com.kaveri.flowershop2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.kaveri.flowershop2.entity.User;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

   
    Optional<User> findByEmail(String email);

  
    Optional<User> findByUsername(String username);
}