package com.kaveri.flowershop2.dto;



public class LoginRequest {
    public String username;
    public String password;
}




