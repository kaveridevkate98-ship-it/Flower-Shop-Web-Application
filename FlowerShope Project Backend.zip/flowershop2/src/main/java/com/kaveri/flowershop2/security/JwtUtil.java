package com.kaveri.flowershop2.security;

import org.springframework.stereotype.Component;

@Component
public class JwtUtil {

   
    public String generateToken(String username) {
        return username + "-token";
    }

    public String extractUsername(String token) {
        return token.replace("-token", "");
    }

    public boolean validateToken(String token) {
        return token != null && token.endsWith("-token");
    }
}
























//
//import io.jsonwebtoken.*;
//import io.jsonwebtoken.security.Keys;
//import org.springframework.stereotype.Component;
//
//import java.security.Key;
//import java.util.Date;
//
//@Component
//public class JwtUtil {
//
//    // 🔐 secret key (must be long & secure)
//    private final String SECRET = "mysecretkeymysecretkeymysecretkey12345";
//
//    private Key getKey() {
//        return Keys.hmacShaKeyFor(SECRET.getBytes());
//    }
//
//    // ✅ generate token
//    public String generateToken(String username) {
//        return Jwts.builder()
//                .setSubject(username)               // store username
//                .setIssuedAt(new Date())            // created time
//                .setExpiration(
//                        new Date(System.currentTimeMillis() + 86400000)
//                )                                   // 24 hours expiry
//                .signWith(getKey(), SignatureAlgorithm.HS256)
//                .compact();
//    }
//
//    // ✅ extract username from token
//    public String extractUsername(String token) {
//        return Jwts.parserBuilder()
//                .setSigningKey(getKey())
//                .build()
//                .parseClaimsJws(token)
//                .getBody()
//                .getSubject();
//    }
//
//    // ✅ validate token
//    public boolean validateToken(String token) {
//        try {
//            Jwts.parserBuilder()
//                    .setSigningKey(getKey())
//                    .build()
//                    .parseClaimsJws(token);
//            return true;
//        } catch (JwtException e) {
//            return false;
//        }
//    }
//}