package com.kaveri.flowershop2.dto;



public class RegisterRequest {
    public String username;
    public String email;
    public String password;
}


