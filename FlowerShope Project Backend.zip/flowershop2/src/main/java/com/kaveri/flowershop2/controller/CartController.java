package com.kaveri.flowershop2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.kaveri.flowershop2.entity.Cart;
import com.kaveri.flowershop2.service.CartService;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = "http://localhost:3000")
public class CartController {

    @Autowired
    private CartService service;

    //ADD TO CART
    @PostMapping("/add/{flowerId}")
    public Cart addToCart(@PathVariable Long flowerId,
                          @RequestParam String username) {
        return service.add(username, flowerId);
    }

    // GET CART
    @GetMapping
    public List<Cart> getCart(@RequestParam String username) {
        return service.getCart(username);
    }

    // REMOVE
    @DeleteMapping("/remove/{flowerId}")
    public void remove(@PathVariable Long flowerId,
                       @RequestParam String username) {
        service.remove(username, flowerId);
    }
}













































