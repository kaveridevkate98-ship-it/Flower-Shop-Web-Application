package com.kaveri.flowershop2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kaveri.flowershop2.entity.Flower;
import com.kaveri.flowershop2.repository.FlowerRepository;

import java.util.List;

@Service
public class FlowerService {

    @Autowired
    private FlowerRepository repo;

 
    public List<Flower> getAll() {
        return repo.findAll();
    }

  
    public Flower save(Flower flower) {
        return repo.save(flower);
    }

    
    public void delete(Long id) {
        repo.deleteById(id);
    }

   
    public List<Flower> getByCategory(String category) {
        return repo.findByCategory(category);
    }
}
