package com.kaveri.flowershop2.controller;


import com.kaveri.flowershop2.entity.Role;
import com.kaveri.flowershop2.entity.User;
import com.kaveri.flowershop2.repository.UserRepository;
import com.kaveri.flowershop2.security.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private UserRepository repo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/register")
    public String register(@RequestBody User user) {

        if (repo.findByEmail(user.getEmail()).isPresent()) {
            return "Email already registered";
        }

        // encrypt password
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // set default role USER
        user.setRoles(Collections.singleton(Role.ROLE_USER));

        repo.save(user);

        return "User registered successfully";
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> request) {

        String email = request.get("email");
        String password = request.get("password");

        User user = repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        String token = jwtUtil.generateToken(user.getEmail());

       
        return Map.of("token", token);
    }
}