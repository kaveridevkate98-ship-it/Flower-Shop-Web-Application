package com.kaveri.flowershop2.controller;



import org.springframework.web.bind.annotation.*;

import com.kaveri.flowershop2.entity.Flower;
import com.kaveri.flowershop2.repository.FlowerRepository;

@RestController
@RequestMapping("/api/admin/flowers")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminFlowerController {

    private final FlowerRepository repo;

    public AdminFlowerController(FlowerRepository repo) {
        this.repo = repo;
    }

    @PostMapping
    public Flower addFlower(@RequestBody Flower flower) {
        return repo.save(flower);
    }

    @PutMapping("/{id}")
    public Flower updateFlower(@PathVariable Long id, @RequestBody Flower flower) {
        flower.setId(id);
        return repo.save(flower);
    }

    @DeleteMapping("/{id}")
    public void deleteFlower(@PathVariable Long id) {
        repo.deleteById(id);
    }
}
