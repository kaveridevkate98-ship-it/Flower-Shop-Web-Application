package com.kaveri.flowershop2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.kaveri.flowershop2.entity.Flower;
import com.kaveri.flowershop2.service.FlowerService;

import java.util.List;

@RestController
@RequestMapping("/api/flowers")
@CrossOrigin(origins = "http://localhost:3000")
public class FlowerController {

    @Autowired
    private FlowerService service;

  
    @GetMapping
    public List<Flower> getAll() {
        return service.getAll();
    }

    
    @PostMapping("/add")
    public Flower add(@RequestBody Flower flower) {
        return service.save(flower);
    }

  
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    @GetMapping("/category/{category}")
    public List<Flower> getByCategory(@PathVariable String category) {
        return service.getByCategory(category);
    }
}