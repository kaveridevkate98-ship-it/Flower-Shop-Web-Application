package com.kaveri.flowershop2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Flowershop2Application {

	public static void main(String[] args) {
		SpringApplication.run(Flowershop2Application.class, args);
	}

}
