package com.kaveri.flowershop2.repository;


import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.kaveri.flowershop2.entity.Order;


public interface OrderRepository extends JpaRepository<Order,Long> {
    List<Order> findByUserId(Long userId);
}
