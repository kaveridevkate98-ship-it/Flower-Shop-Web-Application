package com.kaveri.flowershop2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.kaveri.flowershop2.entity.Role;
import com.kaveri.flowershop2.entity.User;
import com.kaveri.flowershop2.repository.UserRepository;

import java.util.Optional;
import java.util.Set;

@Service
public class UserService {

    @Autowired
    private UserRepository repo;

    @Autowired
    private PasswordEncoder passwordEncoder;

   
    public User register(User user) {
        // Encrypt password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Assign default role
        user.setRoles(Set.of(Role.ROLE_USER));

        return repo.save(user);
    }

   
    public boolean login(String username, String password) {
        Optional<User> optionalUser = repo.findByUsername(username);

        if (optionalUser.isEmpty()) {
            return false;
        }

        User existingUser = optionalUser.get();

        // Compare encrypted password
        return passwordEncoder.matches(password, existingUser.getPassword());
    }
}