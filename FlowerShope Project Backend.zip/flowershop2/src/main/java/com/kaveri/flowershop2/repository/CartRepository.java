package com.kaveri.flowershop2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.kaveri.flowershop2.entity.Cart;
import com.kaveri.flowershop2.entity.User;
import com.kaveri.flowershop2.entity.Flower;

import java.util.List;
import java.util.Optional;

public interface CartRepository extends JpaRepository<Cart, Long> {

    Optional<Cart> findByUserAndFlower(User user, Flower flower);

    List<Cart> findByUser(User user);
}





























