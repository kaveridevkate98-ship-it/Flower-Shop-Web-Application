package com.kaveri.flowershop2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.kaveri.flowershop2.entity.Order;
import com.kaveri.flowershop2.service.OrderService;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:3000")
public class OrderController {

    @Autowired
    private OrderService service;

  
    @PostMapping("/place")
    public Order place(@RequestParam String username){
        return service.place(username);
    }

  
    @GetMapping("/my")
    public List<Order> myOrders(@RequestParam String username) {
        return service.getOrders(username);
    }
}


























//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import com.kaveri.flowershop2.entity.Order;
//import com.kaveri.flowershop2.service.OrderService;
//
//import java.security.Principal;
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/orders")
//@CrossOrigin(origins = "http://localhost:3000")
//public class OrderController {
//
//    @Autowired
//    private OrderService service;
//
//    // ✅ Place Order
//    @PostMapping("/place")
//    public Order placeOrder(Principal principal) {
//        return service.place(principal.getName());
//    }
//
//    // ✅ Get Logged-in User Orders
//    @GetMapping("/my")
//    public List<Order> getMyOrders(Principal principal) {
//        return service.getMyOrders(principal.getName());
//    }
//
//    // ✅ Update Order Status (Cancel / Update)
//    @PutMapping("/update/{id}")
//    public Order updateOrderStatus(
//            @PathVariable Long id,
//            @RequestParam String status) {
//        return service.updateStatus(id, status);
//    }
//}