package com.kaveri.flowershop2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kaveri.flowershop2.entity.Cart;
import com.kaveri.flowershop2.entity.Order;
import com.kaveri.flowershop2.entity.User;
import com.kaveri.flowershop2.repository.OrderRepository;
import com.kaveri.flowershop2.repository.UserRepository;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private CartService cartService;

    @Autowired
    private UserRepository userRepo;

  
    public Order place(String email) {

        //find user by EMAIL 
        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        //get cart items
        List<Cart> cartItems = cartService.getCart(email);

        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }

        //calculate total
        double total = cartItems.stream()
                .mapToDouble(c -> c.getFlower().getPrice() * c.getQuantity())
                .sum();

        //create order
        Order order = new Order();
        order.setUserId(user.getId());
        order.setTotalAmount(total);
        order.setStatus("PLACED");
        order.setOrderDate(LocalDateTime.now());

        Order savedOrder = orderRepo.save(order);

        return savedOrder;
    }

 
    public List<Order> getOrders(String email) {

        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return orderRepo.findByUserId(user.getId());
    }
}