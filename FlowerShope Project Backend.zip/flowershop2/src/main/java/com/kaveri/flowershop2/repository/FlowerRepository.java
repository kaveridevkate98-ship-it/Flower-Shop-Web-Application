package com.kaveri.flowershop2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.kaveri.flowershop2.entity.Flower;
import java.util.List;

public interface FlowerRepository extends JpaRepository<Flower,Long> {

    List<Flower> findByCategory(String category);
    
   
}
