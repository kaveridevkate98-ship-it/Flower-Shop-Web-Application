package com.kaveri.flowershop2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kaveri.flowershop2.entity.Cart;
import com.kaveri.flowershop2.entity.Flower;
import com.kaveri.flowershop2.entity.User;
import com.kaveri.flowershop2.repository.CartRepository;
import com.kaveri.flowershop2.repository.FlowerRepository;
import com.kaveri.flowershop2.repository.UserRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepo;

    @Autowired
    private FlowerRepository flowerRepo;

    @Autowired
    private UserRepository userRepo;

   
    public Cart add(String email, Long flowerId) {

        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Flower flower = flowerRepo.findById(flowerId)
                .orElseThrow(() -> new RuntimeException("Flower not found"));

        Optional<Cart> existing = cartRepo.findByUserAndFlower(user, flower);

        if (existing.isPresent()) {
            Cart cart = existing.get();
            cart.setQuantity(cart.getQuantity() + 1);
            return cartRepo.save(cart);
        }

        Cart cart = new Cart();
        cart.setUser(user);
        cart.setFlower(flower);
        cart.setQuantity(1);

        return cartRepo.save(cart);
    }

    //GET CART
    public List<Cart> getCart(String email) {
        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return cartRepo.findByUser(user);
    }

    //REMOVE ITEM
    public void remove(String email, Long flowerId) {

        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Flower flower = flowerRepo.findById(flowerId)
                .orElseThrow(() -> new RuntimeException("Flower not found"));

        cartRepo.findByUserAndFlower(user, flower)
                .ifPresent(cartRepo::delete);
    }
}













