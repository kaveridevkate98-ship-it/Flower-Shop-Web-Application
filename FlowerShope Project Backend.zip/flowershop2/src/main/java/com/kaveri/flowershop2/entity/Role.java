package com.kaveri.flowershop2.entity;

public enum Role {
	 ROLE_ADMIN,
	    ROLE_USER

}


