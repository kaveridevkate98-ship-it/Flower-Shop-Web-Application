package com.kaveri.flowershop2.service;

import com.paypal.core.PayPalEnvironment;
import com.paypal.core.PayPalHttpClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class PayPalService {

    private PayPalHttpClient client;

    public PayPalService(
            @Value("${paypal.client-id}") String clientId,
            @Value("${paypal.client-secret}") String clientSecret
    ) {

        PayPalEnvironment environment =
                new PayPalEnvironment.Sandbox(clientId, clientSecret);

        client = new PayPalHttpClient(environment);
    }

    public PayPalHttpClient client() {
        return client;
    }
}